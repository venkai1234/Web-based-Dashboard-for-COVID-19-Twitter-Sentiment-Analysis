from pythondjangoapp.settings.base import *

DEBUG = True

INSTALLED_APPS += (
                   # other apps for local development
                   )
